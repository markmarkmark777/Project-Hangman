system = input
System = input
play_game = True
play_game2 = False
man = input
aMan = input
letter = input
new = input
Incorrect = input
Good_list = input
bad_list = input
word = input
Draw = input
n = "thanks for playing!"
y = 'okay! get ready'

print('Welcome To Hangman Game!')
print("do you want to play a game? \n")

play_game = input("do you want to play again? \n")
if play_game == "y":
    if False == "n":
        if n == print('Thanks for playing! We Hope You Play Again!'):
            exit()

    def play_game():
        play_game == n

    input()
    play_game()
    man.Draw()
Draw(play_game)
Draw == "y"
play_game.input(
    'please enter a letter: get the first letter of the string, Capitalized it letter'
)
print(Good_list)
print(bad_list)
